package tests.policies;

import com.intuit.karate.junit5.Karate;

class PoliciesRunner {
    
    @Karate.Test
    Karate testSearch() {
        return Karate.run("policies").relativeTo(getClass());
    }    

}
