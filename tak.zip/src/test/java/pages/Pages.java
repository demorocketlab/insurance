/* denislitvinenko created on 24.01.2025 inside the package - pages */

package pages;

import com.intuit.karate.driver.Driver;
import pages.policy.PolicyPage;
import pages.policy.TopBarComponent;
import pages.start.StartPage;

public class Pages {
    public StartPage startPage;
    public PolicyPage policyPage;

    public Pages(Object driverObj) {
        startPage = new StartPage((Driver) driverObj);
        policyPage = new PolicyPage((Driver) driverObj);
    }
}
