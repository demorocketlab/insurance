/* denislitvinenko created on 23.01.2025 inside the package - pages */

package pages;

import com.intuit.karate.driver.Driver;

public class BasePage {
    protected Driver driver;

    // main top navigation
    private String startLink = "#appmenu-start";
    private String policeLink = "#appmenu-policy";
    private String partnerLink = "#partner-menu-item";

    // modal dialog
    private String dialogWindow = "#overlay";
    private String okButton = "#okButton";
    private String cancelButton = "#cancelButton";

    protected void openStartNavigationMenu() {
        driver.click(startLink);
    }

    protected void openPoliceNavigationMenu() {
        driver.click(policeLink);
    }

    protected void openPartnerNavigationMenu() {
        driver.click(partnerLink);
    }

    protected void confirmDialog() {
        driver.waitFor(dialogWindow);
        driver.click(okButton);
    }

    protected void cancelDialog() {
        driver.waitFor(dialogWindow);
        driver.click(cancelButton);
    }
}
