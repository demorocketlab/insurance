/* denislitvinenko created on 23.01.2025 inside the package - pages */

package pages.start;

import com.intuit.karate.driver.Driver;
import pages.BasePage;

public class StartPage extends BasePage {
    private String policyLink = "//*[@id='policyNr']//a[text()='%s']";

    public StartPage(Driver driverObj) {
        this.driver = driverObj;
    }

    public void openPolicyById(String id) {
        driver.waitFor(String.format(policyLink, id)).click();
    }
}
