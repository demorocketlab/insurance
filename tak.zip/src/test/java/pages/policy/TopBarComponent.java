package pages.policy;

import pages.BasePage;

public class TopBarComponent extends BasePage {
    private String titleText = "//h2";
    private String resumeButton = "resumeButton";
    private String discardPendingButton = "#discardPendingButton";
    private String cancelButton = "#cancelButton";

    // navigation tabs
    private String contractsTabButton = "#prp-contract-tab";

    public TopBarComponent(Driver driverObj) {
        this.driver = driverObj;
    }

    public void checkPolicyTitle(String title) {
        assertEquals(title, driver.text(), "Check if policy title is correct.");
    }

    public void clickResumeButton() {
        driver.click(resumeButton);
    }

    public void clickDiscardPendingButton() {
        driver.click(discardPendingButton);
    }

    public void clickCancelButton() {
        driver.click(cancelButton);
    }

    public void openContractsTab() {
        driver.click(contractsTabButton);
    }
}
