package pages.policy;

import pages.BasePage;

import java.util.HashMap;
import java.util.Map;

public class ContractsTabComponent extends BasePage {

    private String propertyDamageCheckbox = "#input-vaadin-checkbox-2289";
    private String lossOfIncomeCheckbox = "#input-vaadin-checkbox-2290";
    private final Map<String, String> propertyDamageCheckboxes = new HashMap<String, String>() {{
        put("Feuer", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-10']/vaadin-checkbox");
        put( "Fahrzeuganprall, Rauch, Überschalldruckwelle", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-13']/vaadin-checkbox");
        put("Einbruchdiebstahl, Raub, Vandalismus", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-16']/vaadin-checkbox");
        put("Leitungswasser, Rohrbruch, Frost", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-19']/vaadin-checkbox");
        put("Leckage stationärer Brandschutzanlage", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-22']/vaadin-checkbox");
        put("Sturm, Hagel", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-25']/vaadin-checkbox");
        put("Innere Unruhen", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-28']/vaadin-checkbox");
        put("Überschwemmung", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-31']/vaadin-checkbox");
        put("Erdfall", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-34']/vaadin-checkbox");
        put("Schneedruck", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-37']/vaadin-checkbox");
        put("Erdbeben", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-40']/vaadin-checkbox");
        put("Vulkanausbruch", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-43']/vaadin-checkbox");
        put("Glasbruch", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-46']/vaadin-checkbox");
        put("Äußere Einwirkung von unbenannten Gefahren", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-49']/vaadin-checkbox");
        put("Terror", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-52']/vaadin-checkbox");
        put("Elektronik", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-55']/vaadin-checkbox");
        put("Haustechnik", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-58']/vaadin-checkbox");
        put("Maschinenbruch", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-61']/vaadin-checkbox");
        put("Rohbau (Feuer)", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-64']/vaadin-checkbox");
    }};
    private final Map<String, String> lossOfIncomeeCheckboxes = new HashMap<String, String>() {{
        put("Feuer", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-11']/vaadin-checkbox");
        put( "Fahrzeuganprall, Rauch, Überschalldruckwelle", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-14']/vaadin-checkbox");
        put("Einbruchdiebstahl, Raub, Vandalismus", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-17']/vaadin-checkbox");
        put("Leitungswasser, Rohrbruch, Frost", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-20']/vaadin-checkbox");
        put("Leckage stationärer Brandschutzanlage", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-23']/vaadin-checkbox");
        put("Sturm, Hagel", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-26']/vaadin-checkbox");
        put("Innere Unruhen", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-29']/vaadin-checkbox");
        put("Überschwemmung", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-32']/vaadin-checkbox");
        put("Erdfall", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-35']/vaadin-checkbox");
        put("Schneedruck", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-38']/vaadin-checkbox");
        put("Erdbeben", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-41']/vaadin-checkbox");
        put("Vulkanausbruch", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-44']/vaadin-checkbox");
        put("Glasbruch", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-47']/vaadin-checkbox");
        put("Äußere Einwirkung von unbenannten Gefahren", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-50']/vaadin-checkbox");
        put("Terror", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-53']/vaadin-checkbox");
        put("Elektronik", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-56']/vaadin-checkbox");
        put("Haustechnik", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-59']/vaadin-checkbox");
        put("Maschinenbruch", "//vaadin-grid-cell-content[@slot='vaadin-grid-cell-content-62']/vaadin-checkbox");
    }};

    public ContractsTabComponent(Driver driverObj) {
        this.driver = driverObj;
    }

    public void tickPropertyDamageCheckbox() {
        driver.click(propertyDamageCheckbox);
    }

    public void tickLossOfIncomeCheckbox() {
        driver.click(lossOfIncomeCheckbox);
    }

    public void verifyPropertyDamageRisksGroupCheckboxesSelectedByDefault() {
        // verify if first 14 checkboxes are selected by default
        propertyDamageCheckboxes.entrySet().stream()
            .limit(14)
            .forEach(entry -> {
                String checkedAttr = driver.get(entry.getValue()).getAttribute("checked");
                assertTrue(checkedAttr != null, "Check if" + entry.getKey() + " is checked within Sachschäden group");
            });
        // verify if last 5 checkboxes are not selected by default
        propertyDamageCheckboxes.entrySet().stream()
            .skip(14)
            .limit(5)
            .forEach(entry -> {
                String checkedAttr = driver.get(entry.getValue()).getAttribute("checked");
                assertFalse(checkedAttr != null, "Check if" + entry.getKey() + " isn't checked within Sachschäden group");
            });
    }

    public void verifyLossOfIncomeRisksGroupCheckboxesSelectedByDefault() {
        // verify if first 14 checkboxes are selected by default
        lossOfIncomeeCheckboxes.entrySet().stream()
            .limit(14)
            .forEach(entry -> {
                String checkedAttr = driver.get(entry.getValue()).getAttribute("checked");
                assertTrue(checkedAttr != null, "Check if" + entry.getKey() + " is checked within Ertragsausfall group");
            });
        // verify if last 4 checkboxes are not selected by default
        lossOfIncomeeCheckboxes.entrySet().stream()
            .skip(14)
            .limit(4)
            .forEach(entry -> {
                String checkedAttr = driver.get(entry.getValue()).getAttribute("checked");
                assertFalse(checkedAttr != null, "Check if" + entry.getKey() + " isn't checked within Ertragsausfall group");
            });
    }

    public void inversePropertyDamageRisksGroupCheckboxesSelection() {
        propertyDamageCheckboxes.forEach((key, value) -> {
            driver.click(value);
        });
    }

    public void inverseLossOfIncomeRisksGroupCheckboxesSelection() {
        lossOfIncomeeCheckboxes.forEach((key, value) -> {
            driver.click(value);
        });
    }

    public void verifyPropertyDamageRisksGroupCheckboxesNotSelected() {
        propertyDamageCheckboxes.forEach((key, value) -> {
            String checkedAttr = driver.get(value).getAttribute("checked");
            assertFalse(checkedAttr != null, "Check if" + key + " isn't checked within Sachschäden group");
        });
    }

    public void verifyLossOfIncomeRisksGroupCheckboxesNotSelected() {
        propertyDamageCheckboxes.forEach((key, value) -> {
            String checkedAttr = driver.get(value).getAttribute("checked");
            assertFalse(checkedAttr != null, "Check if" + key + " isn't checked within Ertragsausfall group");
        });
    }
}
