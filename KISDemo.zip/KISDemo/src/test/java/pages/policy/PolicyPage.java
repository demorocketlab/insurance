package pages.policy;

import com.intuit.karate.driver.Driver;
import pages.BasePage;

public class PolicyPage {
    public TopBarComponent topBar;
    public ContractsTabComponent contractsTab;

    public PolicyPage(Driver driverObj) {
        topBar = new TopBarComponent(driverObj);
        contractsTab = new ContractsTabComponent(driverObj);
    }

}
